# GANGLIA MONITOR CORE

[![Build Status](https://secure.travis-ci.org/ganglia/monitor-core.png)](http://travis-ci.org/ganglia/monitor-core)

