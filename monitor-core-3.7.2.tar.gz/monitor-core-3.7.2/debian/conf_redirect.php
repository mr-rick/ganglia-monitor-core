<?php

include( "/etc/ganglia-frontend/conf_default.php" );

?>
