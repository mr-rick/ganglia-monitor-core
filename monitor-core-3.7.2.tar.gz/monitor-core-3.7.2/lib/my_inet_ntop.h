#ifndef MY_INET_NTOP_H
#define MY_INET_NTOP_H 1
const char *my_inet_ntop( int af, void *src, char *dst, size_t cnt );
#endif
