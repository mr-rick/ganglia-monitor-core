while(true); do ./rrdupdate.py $1 $2; sleep 1m; done;
